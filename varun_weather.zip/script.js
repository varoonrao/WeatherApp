class Weather{
    constructor(temperature_max, temperature_min, current_place){
        this.temperature_max=max_temperature;
        this.temperature_min=min_temperature;
        this.current_place=place;
    }
}  